# app/routers/documents.py

import os
import uuid
from fastapi import APIRouter, Depends, UploadFile, File, BackgroundTasks, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session
from .. import models, security
from ..database import SessionLocal

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/upload")
def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    current_admin: dict = Depends(security.get_current_admin_user),
    db: Session = Depends(get_db)
):
    """
    Admin-only: save the PDF bytes in Postgres and kick off background embedding.
    """
    company_id = current_admin["company_id"]

    # Read the file *once* into memory so we can both store it and write a temp file
    file_bytes = file.file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Empty file upload.")

    # Create DB row with file bytes
    db_document = models.Document(
        filename=file.filename,
        content_type=getattr(file, "content_type", None) or "application/pdf",
        file_size=len(file_bytes),
        file_data=file_bytes,
        company_id=company_id,
        status=models.StatusEnum.processing,
    )
    db.add(db_document)
    db.commit()
    db.refresh(db_document)

    # Write a unique temp file for the background processor
    # (We process from disk for PdfReader; the DB remains our source-of-truth copy.)
    safe_name = file.filename.replace(os.sep, "_")
    temp_file_path = f"temp_{db_document.id}_{uuid.uuid4().hex}_{safe_name}"
    with open(temp_file_path, "wb") as f:
        f.write(file_bytes)

    from ..processing import process_and_store_document
    background_tasks.add_task(
        process_and_store_document,
        file_path=temp_file_path,
        filename=file.filename,
        company_id=company_id,
        document_id=db_document.id
    )

    return {
        "message": "File uploaded and processing has started.",
        "document_id": db_document.id,
        "filename": file.filename
    }

@router.get("/download/{document_id}")
def download_document(
    document_id: int,
    current_admin: dict = Depends(security.get_current_admin_user),
    db: Session = Depends(get_db)
):
    """
    Admin-only: download the original PDF bytes stored in DB.
    Restricts access to the doc's own company.
    """
    company_id = current_admin["company_id"]
    doc = (
        db.query(models.Document)
        .filter(models.Document.id == document_id, models.Document.company_id == company_id)
        .first()
    )
    if not doc or not doc.file_data:
        raise HTTPException(status_code=404, detail="Document not found or no file stored.")

    return Response(
        content=doc.file_data,
        media_type=doc.content_type or "application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{doc.filename}"'
        },
    )


@router.get("/")
def list_documents(
    current_admin: dict = Depends(security.get_current_admin_user),
    db: Session = Depends(get_db)
):
    """
    Admin-only: list all documents uploaded for the admin's company
    """
    company_id = current_admin["company_id"]
    docs = db.query(models.Document).filter(models.Document.company_id == company_id).all()

    if not docs:
        return []

    # Return minimal info for frontend
    return [
        {
            "id": d.id,
            "filename": d.filename,
            "status": d.status.value,
            "uploaded_at": d.uploaded_at
        }
        for d in docs
    ]